library("testthat")
library("vsn")

test_check("vsn")
