# parody

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![BioC
status](http://www.bioconductor.org/shields/build/release/bioc/parody.svg)](https://bioconductor.org/checkResults/release/bioc-LATEST/parody)
[![BioC dev
status](http://www.bioconductor.org/shields/build/devel/bioc/parody.svg)](https://bioconductor.org/checkResults/devel/bioc-LATEST/parody)
[![R build
status](https://github.com/vjcitn/parody/workflows/R-CMD-check-bioc/badge.svg)](https://github.com/vjcitn/parody/actions)
[![Codecov test
coverage](https://codecov.io/gh/vjcitn/parody/branch/master/graph/badge.svg)](https://codecov.io/gh/vjcitn/parody?branch=master)
[![Support site activity, last 6 months: tagged questions/avg. answers
per question/avg. comments per question/accepted answers, or 0 if no
tagged
posts.](http://www.bioconductor.org/shields/posts/parody.svg)](https://support.bioconductor.org/t/parody/)
[![GitHub
issues](https://img.shields.io/github/issues/vjcitn/parody)](https://github.com/vjcitn/parody/issues)
<!-- badges: end -->

parametric outlier dytection tools
