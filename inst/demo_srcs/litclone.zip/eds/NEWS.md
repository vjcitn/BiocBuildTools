# eds 0.99.1

* Added a `NEWS.md` file to track changes to the package.
