# eds
Reader for Alevin's EDS format
