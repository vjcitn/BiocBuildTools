library(testthat)
library(eds)

test_check("eds")
